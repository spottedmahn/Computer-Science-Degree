//File IO
#include <iostream>
#include <fstream>
#include <iomanip>

#include <stdio.h>

#include <cstdlib>
#include <cctype>

#include <string>