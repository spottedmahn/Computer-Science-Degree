#include <iostream>
#include <fstream>

using namespace std;

int main(){

	ifstream fileIn;
	ofstream fileOut;
	
	fileIn.open("in.txt");
	fileOut.open("out.dat");
	
	int tmpI, tmpI2;
	char tmpC;
	
	fileIn >> tmpI >> tmpI2;
	fileOut << "Sum of " << tmpI << " and " << tmpI2 << " = " << tmpI + tmpI2 << "." << endl;
	fileOut.flush();
	
	fileIn >> tmpC;
	fileOut << "The character that comes after A in the ASCII set is " << (char) (tmpC + 1) << endl;
	fileOut.flush();
	
	fileIn >> tmpI >> tmpI2;
	fileOut << "The product of " << tmpI << " and  " << tmpI2 << " = " << tmpI * tmpI2 << "." << endl;
	fileOut.flush();
	
	fileIn.close();
	fileOut.close();
	
	//system("PAUSE");
	return 0;
}