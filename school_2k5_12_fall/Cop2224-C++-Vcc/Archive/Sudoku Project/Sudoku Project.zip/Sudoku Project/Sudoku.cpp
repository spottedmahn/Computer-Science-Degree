//Conventions//
//
//
//variable naming convention:
//         classes - first letter is capitalized
//         variables and methods - first letter is not capitalized, every important
//                                   word after that is caplitalized.
//End Conventions//

//Assumptions//
//
//
//End Assumptions//


bool Sudoku::applyRule1(){
     
     return false;
}

bool Sudoku::applyRule2(){
     
     return false;
}

bool Sudoku::applyRule3(){
     
     return false;
}

bool Sudoku::applyRule4(){
     
     return false;
}

bool Sudoku::applyRule5(){
     
     return false;
}

bool Sudoku::applyRule6(){
     
     return false;
}

bool Sudoku::applyRule7(){
     
     return false;
}

void Sudoku::generateBoard(){
     
}

void Sudoku::guess(){
     
     guess tmpGuess;
     
     return tmpGuess;    
} 

void Sudoku::solve(){
     
          
}

bool Sudoku::isValidateSudokuBoard(){


     return true;    
}
