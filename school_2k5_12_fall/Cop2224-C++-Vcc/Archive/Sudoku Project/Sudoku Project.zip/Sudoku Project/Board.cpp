//Conventions//
//
//
//variable naming convention:
//         classes - first letter is capitalized
//         variables and methods - first letter is not capitalized, every important
//                                   word after that is caplitalized.
//End Conventions//

//Assumptions//
//
//
//End Assumptions//

bool Board::operartor==(const Board&) const{
     
     return true;    
}


