//Conventions//
//
//
//variable naming convention:
//         classes - first letter is capitalized
//         variables and methods - first letter is not capitalized, every important
//                                   word after that is caplitalized.
//End Conventions//

//Assumptions//
//
//
//End Assumptions//

const int numRowsCols = 9;

class Board{

      public:
             bool operartor==(const Board&) const;
      private:
             vector<int> data[X][X];
             const int size = X;      
};
