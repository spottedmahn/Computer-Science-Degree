#include <cstdlib>
#include <iostream>
#include "sudoku.h"
#include "board.h"

using namespace std;

int main(int argc, char *argv[]){
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
