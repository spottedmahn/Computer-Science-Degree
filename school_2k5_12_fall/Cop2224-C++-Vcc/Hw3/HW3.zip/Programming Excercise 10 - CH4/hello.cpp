#include <iostream>

using namespace std; 	//introduces namespace std
int main( void )
{
	cout << "This is a test" ;
	return 0;
}