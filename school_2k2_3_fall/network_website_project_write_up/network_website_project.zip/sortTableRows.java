/***************************************************************

** Michael DePouw

** Date:9 19 02

***************************************************************/
/****************Program Description***************************

** This class was design to organize table data for html. It
** will read in the file and output the organized file. Once it
** sees <!--StartSort--> it will output 1 <tr> 7 strings that begin 
** with <td> and then 1 </tr> until it sees <!--EndSort-->.
** At the end of the fill input file there must be the string
** quit or </html>.

**************************************************************/
import java.io.*;

public class sortTableRows {
	
	private String input;
	private int i;
	private String direct;
	
	public sortTableRows(){
		input = "temp";	
	}
	public void setDirect(String in){
		direct = in;
	}
	public void sortIt(){
		boolean repeat = true, sorting = true, printing = true;
		
		try{

			//setup file input
			FileReader inReader = new FileReader(direct);
			BufferedReader in = new BufferedReader(inReader);
			//setup file output
			FileOutputStream outStream2 = new FileOutputStream("output_sorted.txt");
			PrintWriter printwrite2 = new PrintWriter(outStream2, true);
			//setup file temp td output
			FileOutputStream outStream = new FileOutputStream("output_tmp.txt");
			PrintWriter printwrite = new PrintWriter(outStream, true);
			//reading tmp file back in
			FileReader inReader2 = new FileReader("output_tmp.txt");
			BufferedReader in2 = new BufferedReader(inReader2);
	
			while(repeat){
				try{
					input = in.readLine();
					if(input.compareTo("quit") == 0 || input.compareTo("</html>") == 0){
						repeat = false;
						break;
					}
					else{
						if(input.compareTo("<!--StartSort-->") == 0){
							sorting = true;
				outer1:
							while(sorting){
								input = in.readLine();
								if(input.startsWith("<td>")){
									//printing table data that needs to be organized and sorted to a tmp file
									printwrite.println(input);
								}
								else{
									if(input.compareTo("<!--EndSort-->") == 0){
										// need to know when to stop reading for putting td in a tr
										printwrite.println("quit");
										sorting = false;
										break outer1;
									}
								}
							}//end while
							printwrite2.println("<!--StartSort-->");
							printwrite2.println("<tr>");
							printing = true;
					outer2:
							while(printing){
								for(i=1;i<8;i++){
									input = in2.readLine();
									if(input.compareTo("quit") == 0){
										printwrite2.println("</tr>");
										printwrite2.println("<!--EndSort-->");
										printing = false;
										break outer2;
									}
									else {
										printwrite2.println(input);
										}
									if(i==7){
										printwrite2.println("</tr>");
										printwrite2.println("<tr>");
									}	
								}//end for loop
							}//end while
						}//end if(input compareTo <!--startSort-->)
						else{
							printwrite2.println(input);	
						}
					}//end big else
				}	
				catch(EOFException e){
					System.out.println(e.getMessage());
				}				
			} //endwhile
		printwrite2.println("</html>");
		//closing output_tmp.txt
		printwrite.close();
		// flushing and closing output.txt
		//printwrite2.flush();
		printwrite2.close();
		outStream.close();
		outStream2.close();
		//copying over original file with sorted file
		copyOver();		
		}//end try
		catch (IOException e){
			System.out.println("Error Message = " + e.getMessage());
		}
	}//end method sortIt
	public void copyOver() throws IOException{
		//copying sorted file over orginal file
		FileReader fRead = new FileReader("output_sorted.txt");
		BufferedReader in6 = new BufferedReader(fRead);
		FileOutputStream fStream = new FileOutputStream(direct);
		PrintWriter printWriter = new PrintWriter(fStream, true);
		boolean repeat = true;
		while(repeat){
				//printWriter.println("here");
				input = in6.readLine();
				if(input.compareTo("quit") == 0 || input.compareTo("</html>") == 0){			
					printWriter.println(input);
					repeat = false;
				}
				else{
					printWriter.println(input);
				}
		}	
		printWriter.close();
	}
}
