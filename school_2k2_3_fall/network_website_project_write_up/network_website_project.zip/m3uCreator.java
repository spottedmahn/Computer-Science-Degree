/***************************************************************

** Michael DePouw

** COP3503

** Assignment Number: Final Project 

** Date:10/25/02

***************************************************************/

/****************Class Description***************************

** This class does multiply things. The main thing it does is
** create m3u files.  It will also rename any jpg's in the
** directory to the name of the directory in which the jpg
** is in, then it will copy them to c:\jewel. It will also
** rename any psd files or doc files or tit files to the 
** directory name. It will also delete any files without
** a three or four character file extension. It will also 
** delete sfv files.

**************************************************************/
import java.io.*;

public class m3uCreator {
    
    private String direct;
	 private boolean ImageCopyFlag;
	 
    public m3uCreator() {
    }
	 public void setDirect(String in){
	 	direct = in;
	 }
	 public void setImageCopyFlag(boolean tORf){
	 	ImageCopyFlag = tORf;
	 }
    public void createM3uFiles() throws IOException{
        int i, j;
        String [] directories;
        String [] tmpSA;//temp string array
        String tmpS = new String();//temp string
        File[] tmpFA;//temp file array
        //location of directories
		  File fileIn = new File(direct);
        //putting all directories in new_shit into string array
        directories = fileIn.list();
		  //stepping thru ever directory
        for(i=0;i<directories.length;i++){
			File testIsFile = new File(direct+"\\"+directories[i]);
			if(!testIsFile.isFile()){                   
            tmpS = direct + "\\" + directories[i];
				//current directory
            File currentD = new File(tmpS);
            //m3u file
            FileOutputStream fout = new FileOutputStream(tmpS + "\\" + directories[i] + ".m3u");
            PrintWriter pwriter = new PrintWriter(fout, true);
            //listing all files in  directory
            tmpSA = currentD.list();
            //adding mp3 files to m3u file, renaming jpg, and deleting sfv file
            for(j=0;j<tmpSA.length;j++){
                if(tmpSA[j].endsWith(".mp3") || tmpSA[j].endsWith(".MP3") || tmpSA[j].endsWith(".Mp3") || tmpSA[j].endsWith(".mP3")){
                    pwriter.println(tmpSA[j]);
                }
					 //deleting sfv files
                else if(tmpSA[j].endsWith(".sfv")){
                    File del = new File(tmpS + "\\" + tmpSA[j]);
                    del.delete();
					}
					 //deleting any previous m3u files
					 else if(tmpSA[j].endsWith(".m3u")){
					 		File del = new File(tmpS + "\\" + tmpSA[j]);
							del.delete();
					}
					//deleting files with out extensions
					else if(tmpSA[j].length() > 3){
						if(tmpSA[j].charAt(tmpSA[j].length() - 4) != '.'){
							File del = new File(tmpS + "\\" + tmpSA[j]);
							//testing if file is a directory bc don't want to delete a directory
							if(!del.isDirectory()){
								//special case, file with a four character file extension
								if(!tmpSA[j].endsWith(".html")){
									del.delete();
								}
							}
						}	
					}
					//renaming doc files to directory name
					else if(tmpSA[j].endsWith(".doc")){
						File doc = new File(tmpS + "\\" + tmpSA[j]);
						File tmpF = new File(tmpS + "\\" + directories[i] + ".doc");
						doc.renameTo(tmpF);
					}
					//renaming tit files to directory name
					else if(tmpSA[j].endsWith(".tit")){
						File tit = new File(tmpS + "\\" + tmpSA[j]);
						File tmpF = new File(tmpS + "\\" + directories[i] + ".tit");
						tit.renameTo(tmpF);
					}
					//renaming psd files to directory name
					else if(tmpSA[j].endsWith(".psd")){
						File psd = new File(tmpS + "\\" + tmpSA[j]);
						File tmpF = new File(tmpS + "\\" + directories[i] + ".psd");
						psd.renameTo(tmpF);
					}
					if(ImageCopyFlag){
						 //renaming jpg's to directory name and copying to c:\jewel (zzzz is for file saved from amazon.com
 	 	             if(tmpSA[j].endsWith(".jpg") || tmpSA[j].endsWith("ZZZZ")){
  	      	           File jpg = new File(tmpS + "\\" + tmpSA[j]);
    	   	           File tmpF = new File(tmpS + "\\" + directories[i] + ".jpg");
     	 	              jpg.renameTo(tmpF);
							  try {
							  		int c;
						  			FileInputStream reader = new FileInputStream(tmpS + "\\" + directories[i] + ".jpg");
									FileOutputStream writer = new FileOutputStream( "c:\\jewel\\" + directories[i] + ".jpg");
									while( ( c = reader.read() ) != -1 ) {
										writer.write( c );
									} 
									reader.close();
									writer.close();
							  }
							  catch( IOException ioe ) {
						 	 		ioe.printStackTrace();
							}
	                }
					  //renaming gif's to directory name and copying to c:\jewel 
                else if(tmpSA[j].endsWith(".gif")){
                    File jpg = new File(tmpS + "\\" + tmpSA[j]);
                    File tmpF = new File(tmpS + "\\" + directories[i] + ".gif");
                    jpg.renameTo(tmpF);
						  try {
							  	int c;
						  		FileInputStream reader = new FileInputStream(tmpS + "\\" + directories[i] + ".gif");
								FileOutputStream writer = new FileOutputStream( "c:\\jewel\\" + directories[i] + ".gif");
								while( ( c = reader.read() ) != -1 ) {
									writer.write( c );
								} 
								reader.close();
								writer.close();
						  }
						  catch( IOException ioe ) {
						  		ioe.printStackTrace();
						  }
                }						
					}
				}
				pwriter.close();
        }//ends big for loop
      }
    }//end createM3uFiles   
}
