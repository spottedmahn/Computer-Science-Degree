/***************************************************************

** Michael DePouw

** COP3503

** Assignment Number: Final Project

** Date:10/10/02

***************************************************************/

/****************Class Description***************************\

** This class will create a file with the directory name on a
** line and the title on the next line. It will get the title
** from the tit file in the directory.   

**************************************************************/

import java.io.*;

public class createDirectoryList
{
	private String direct;
	
	public createDirectoryList(){
		
	}
	public void setDirect(String in){
		direct = in;
	}
	public void create() throws IOException{  
		String[] directory;
		int i;
		boolean autoFlush = true;
	  	//input directory
		File fileIn = new File(direct);
	   //listing all files and directories
		directory = fileIn.list();
	  	//setup for text output file
	  	FileOutputStream fout = new FileOutputStream("\\\\musicfactory\\storage\\my_documents\\school_2k2_3_fall\\network_website_project\\input_directory_title.txt");
		PrintWriter pwriter = new PrintWriter(fout, autoFlush);
	   //stepping thru directory array printing directory and then title
		for(i=0;i<directory.length;i++){
		 	//printing only directories
			File testIsFile = new File(direct+"\\"+directory[i]);
			if(!testIsFile.isFile()){			
				//printing directory
				pwriter.println(directory[i]);
				try{
					//reading in title from .tit file
					BufferedReader in = new BufferedReader(new FileReader(direct+"\\"+directory[i]+"\\"+directory[i]+".tit"));
					//printing title
					pwriter.println(in.readLine());
				}
				catch(FileNotFoundException e){
					System.out.println("No .tit file in directory "+directory[i]);
					System.out.println("You will need to add your own title");
				}
			}
		}
		pwriter.println("quit");
		pwriter.close();
	}//end create list method
}
