/***************************************************************

** Michael DePouw

** Date:9 19 02

***************************************************************/

/****************Program Description***************************

** This class is for my intranet site.  It will generate the
** html code for a single ablum. 

**************************************************************/

import java.io.*;


public class tableData
{
		private String directory, title, direct;
		private int count;
		private boolean repeat = true;
		private boolean absolutePath = false;
		char[] dst;
		
	public tableData(){
		directory = "temp";
		
	}
	public void setPath(){
		absolutePath = true;
	}
	public void setDirect(String in){
		direct = in;
	}
	public void create(){
		try {
	
		//Reading in the current count
		FileReader inReader = new FileReader("numFile.txt");
		BufferedReader bReader = new BufferedReader(inReader);	
		count = Integer.parseInt(bReader.readLine());
		bReader.close();
		
		//filereader for input
		FileReader inReader2 = new FileReader("input_directory_title.txt");
		BufferedReader bReader2 = new BufferedReader(inReader2);
		
		// Output.txt file setup
		FileOutputStream outStream = new FileOutputStream("output_directory_title.txt");
		PrintWriter printWriter = new PrintWriter(outStream);
		directory = "a";
		title = "a";
		while((directory != "quit") || (title != "quit")){
			// Reading in directory
			directory = bReader2.readLine();
			if(directory.compareTo("quit") == 0)
				break;
			// Reading in title
			title = bReader2.readLine();
			if(title.compareTo("quit")== 0)
				break;
			// Putting Directory into an array for link setup
			dst = directory.toCharArray();
			if(dst [0] == ' '){
				directory = "quit";
				break;
			}
			//collaborations
			if(direct.compareTo("\\\\musicfactory\\collaborations") == 0){
				printWriter.println("<td><a href=\"\\\\Musicfactory\\collaborations\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\collaborations\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");			
			}
			//absolutePath
			else if(absolutePath){
				printWriter.println("<td><a href=\""+ direct + "\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"" + direct + "\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");			
			}
			//dj freckles
			else if(direct.compareTo("\\\\musicfactory\\dj_freckles") == 0){
				printWriter.println("<td><a href=\"\\\\Musicfactory\\dj_freckles\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\dj_freckles\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");			
			}
			//instrumentals
			else if(direct.compareTo("\\\\musicfactory\\instrumentals") == 0){
				printWriter.println("<td><a href=\"\\\\Musicfactory\\instrumentals\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\instrumentals\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");			
			}
			//albums #-z
			else if(direct.compareTo("\\\\musicfactory\\new_music") == 0){
				if(dst [0] == '0' || dst [0] == '1' || dst [0] == '2' || dst [0] == '3' || dst [0] == '4' || dst [0] == '5' || dst [0] == '6' || dst [0] == '7' || dst [0] == '8' || dst [0] == '9' || dst[0] == 'a' || dst[0] == 'A' || dst[0] == 'b' || dst[0] == 'B' || dst[0] == 'c'  || dst[0] == 'C'){
					printWriter.println("<td><a href=\"\\\\Musicfactory\\albums_#-c\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\albums_#-c\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");
				}
				else if(dst [0] == 'd' || dst [0] == 'D' || dst [0] == 'e' || dst [0] == 'E' || dst [0] == 'f' || dst [0] == 'F' ||	dst [0] == 'g' || dst [0] == 'G' ||	 dst [0] == 'h' || dst [0] == 'H'){
					printWriter.println("<td><a href=\"\\\\Musicfactory\\albums_d-h\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\albums_d-h\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");
				}
				else if(dst [0] == 'i' || dst [0] == 'I' || dst [0] == 'j' || dst [0] == 'J' || dst [0] == 'k' || dst [0] == 'K' || dst [0] == 'l' || dst [0] == 'L' || dst [0] == 'm' ||  dst [0] == 'M'){
					printWriter.println("<td><a href=\"\\\\Musicfactory\\albums_i-m\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\albums_i-m\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");
				}
				else if(dst [0] == 'n' || dst [0] == 'N' || dst [0] == 'o' || dst [0] == 'O' || dst [0] == 'p' || dst [0] == 'P' || dst [0] == 'q' || dst [0] == 'Q' || dst [0] == 'r' || dst [0] == 'R' || dst [0] == 's' || dst [0] == 'S'){
					printWriter.println("<td><a href=\"\\\\Musicfactory\\albums_n-s\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\albums_n-s\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");
				}
				else if(dst [0] == 't' || dst [0] == 'T' || dst [0] == 'u' || dst [0] == 'U' || dst [0] == 'v' || dst [0] == 'V' || dst [0] == 'w' || dst [0] == 'W' || dst [0] == 'x' || dst [0] == 'X' || dst [0] == 'y' || dst [0] == 'Y' || dst [0] == 'z' || dst [0] == 'Z'){
					printWriter.println("<td><a href=\"\\\\Musicfactory\\albums_t-z\\" + directory + "\" onmouseover=\"window.status='" + title + "';return true\" onmouseout=\"window.status='';return true\"><img src=\"C:/jewel/" + directory + ".jpg\" height=\"100\" width=\"100\" alt=\"" + title + "\" border=\"0\"></a><br><a href=\"\\\\Musicfactory\\albums_t-z\\" + directory + "\\" + directory +".m3u\" onMouseOver=\"if(document.images) document.play" + count + ".src='buttons/play1.jpg'; window.status='Click Here To Add " + title + " To Winamp';return true\" onMouseOut=\"if(document.images) document.play" + count + ".src='buttons/play.jpg'; window.status='';return true\"><img src=\"buttons/play.jpg\" border=\"0\" alt=\"Click Here To Add " + title + " To Winamp\" name=\"play" + count + "\"></a><br><img src=\"images/new_shit.jpg\"></td>");
				}
			}
			count++;
		}// end while
		
		// flushing and closing output.txt
		printWriter.flush();
		printWriter.close();
			
		// updating numFile.txt
		FileOutputStream outStreamCount = new FileOutputStream("H:\\storage\\my_documents\\school_2k2_3_fall\\network_website_project\\numFile.txt");
		PrintWriter printWriterCount = new PrintWriter(outStreamCount);
		printWriterCount.println(count);
		printWriterCount.flush();
		printWriterCount.close();
		}
		catch (IOException e){
			System.out.println("Error Message = " +e.getMessage());
		}
	}
}
