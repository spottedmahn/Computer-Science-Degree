/***************************************************************

** Michael DePouw

** Date:9 25 02

***************************************************************/



import java.io.*;

public class mainProject{
	
	public static void main(String[] args) throws IOException {
		String input;
		boolean repeat = true;
		int option, tmpI = 0;
		String tmpS = new String();
		
 		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		tableData table = new tableData();
		sortTableRows sort = new sortTableRows();
		createDirectoryList direcList = new createDirectoryList();
      m3uCreator m3u = new m3uCreator();
		TitCreator tit = new TitCreator();
                	
		while(repeat){
			printOptions();
			input = in.readLine();
			option = Integer.parseInt(input);			
			//title creation
			if(option == 1){
				printDirectoryMenuNew();
				tmpI = Integer.parseInt(in.readLine());
				if(tmpI == 1){
					tit.setDirect("\\\\musicfactory\\new_music");
				}
				else if(tmpI == 2){
					tit.setDirect("\\\\musicfactory\\dj_freckles\\new");
				}
				else if(tmpI == 3){
					tit.setDirect("\\\\musicfactory\\collaborations\\new");
				}
				else if(tmpI == 4){
					tit.setDirect("\\\\musicfactory\\instrumentals\\new");
				}
				else if(tmpI == 5){
					printDirectoryMenuOption5();
					String titS = new String();
					titS = in.readLine();
					tit.setDirect(titS);
				}																				
				tit.create();
			} 			
			//listing directories
			else if(option == 2){
				printDirectoryMenuNew();
				tmpI = Integer.parseInt(in.readLine());
				if(tmpI == 1){
					direcList.setDirect("\\\\musicfactory\\new_music");
				}
				else if(tmpI == 2){
					direcList.setDirect("\\\\musicfactory\\dj_freckles\\new");
				}
				else if(tmpI == 3){
					direcList.setDirect("\\\\musicfactory\\collaborations\\new");
				}				
				else if(tmpI == 4){
					direcList.setDirect("\\\\musicfactory\\instrumentals\\new");
				}
				else if(tmpI == 5){
					printDirectoryMenuOption5();
					String titS = new String();
					titS = in.readLine();
					direcList.setDirect(titS);
				}								
				direcList.create();
			}
			//create td(s)
			else if(option == 3){
				printDirectoryMenuNew();
				tmpI = Integer.parseInt(in.readLine());
				if(tmpI == 1){
					table.setDirect("\\\\musicfactory\\new_music");
				}
				else if(tmpI == 2){
					table.setDirect("\\\\musicfactory\\dj_freckles\\new");
				}
				else if(tmpI == 3){
					table.setDirect("\\\\musicfactory\\collaborations\\new");
				}
				else if(tmpI == 4){
					table.setDirect("\\\\musicfactory\\instrumentals\\new");
				}									
				else if(tmpI == 5){
					printDirectoryMenuOption5();
					String titS = new String();
					titS = in.readLine();
					table.setPath();
					table.setDirect(titS);
				}				
				table.create();
			}
			//m3u creation
         else if(option == 4){
				printDirectoryMenu();
				tmpI = Integer.parseInt(in.readLine());
				if(tmpI == 1){
					m3u.setDirect("\\\\musicfactory\\new_music");
				}
				else if(tmpI == 2){
					m3u.setDirect("\\\\musicfactory\\dj_freckles");
				}
				else if(tmpI == 3){
					m3u.setDirect("\\\\musicfactory\\collaborations");
				}
				else if(tmpI == 4){
					m3u.setDirect("\\\\musicfactory\\instrumentals");
				}								
				else if(tmpI == 5){
					System.out.println("Please enter an absolute path. example c:\\my_music");
					String titS = new String();
					titS = in.readLine();
					m3u.setDirect(titS);
				}
				System.out.println("Copy images to c:\\jewel ?");
				System.out.println("1 for yes");
				System.out.println("2 for no");
				tmpS = in.readLine();
				if(tmpS.compareTo("1") == 0){
					m3u.setImageCopyFlag(true);
				}
				else{
					m3u.setImageCopyFlag(false);
				}			
            m3u.createM3uFiles();
         }				
			//organzing td into seven td(s) in one tr
			else if(option == 5){
				printSortMenu();
				tmpI = Integer.parseInt(in.readLine());
				if(tmpI == 1){
					sort.setDirect("\\\\musicfactory\\network_website\\albums_#-c.htm");
				}
				else if(tmpI == 2){
					sort.setDirect("\\\\musicfactory\\network_website\\albums_d-h.htm");
				}
				else if(tmpI == 3){
					sort.setDirect("\\\\musicfactory\\network_website\\albums_i-m.htm");
				}
				else if(tmpI == 4){
					sort.setDirect("\\\\musicfactory\\network_website\\albums_n-s.htm");
				}
				else if(tmpI == 5){
					sort.setDirect("\\\\musicfactory\\network_website\\albums_t-z.htm");
				}
				else if(tmpI == 6){
					sort.setDirect("\\\\musicfactory\\network_website\\new_shit.htm");
				}
				else if(tmpI == 7){
					sort.setDirect("\\\\musicfactory\\network_website\\custom_cdz.htm");
				}		
				else if(tmpI == 8){
					sort.setDirect("\\\\musicfactory\\network_website\\instrumentals.htm");
				}																							
				else if(tmpI == 9){
				
					printSortMenuOwnPath();
					String titS = new String();
					titS = in.readLine();
					//sort.setPath();
					sort.setDirect(titS);
				}				
				sort.sortIt();
			}

			//quit option                        
         else if(option == 6){
				repeat = false;
				break;
			}
                       
			else{
				System.out.println("Error: You need to enter a number between 1 and 5");
			}
		}//end while
	}//main
	public static void printOptions(){
		System.out.println();
		System.out.println("1 for title creation");
  		System.out.println("2 for creating directory list");
		System.out.println("3 for table data creation");
		System.out.println("4 for m3u creation");
		System.out.println("5 for sorting table rows");
		System.out.println("6 to quit");
		System.out.println();
	}
	public static void printDirectoryMenuNew(){
		System.out.println();
		System.out.println("1 for new music");
		System.out.println("2 for new dj freckles");
		System.out.println("3 for new collaborations");
		System.out.println("4 for new instrumentals");
		System.out.println("5 for your own path");
		System.out.println();
	}
	public static void printDirectoryMenu(){
		System.out.println();
		System.out.println("1 for new music");
		System.out.println("2 for dj freckles");
		System.out.println("3 for collaborations");
		System.out.println("4 for instrumentals");
		System.out.println("5 for your own path");
		System.out.println();
	}	
	public static void printDirectoryMenuOption5(){
		System.out.println("Please enter an absolute path. example c:\\my_music");
		System.out.println();
	}
	public static void printSortMenu(){
		System.out.println();
		System.out.println("1 for albums_#-c.htm");
		System.out.println("2 for albums_d-h.htm");
		System.out.println("3 for albums_i-m.htm");
		System.out.println("4 for albums_n-s.htm");
		System.out.println("5 for albums_t-z.htm");
		System.out.println("6 for new_music.htm");
		System.out.println("7 for custom_cdz.htm");
		System.out.println("8 for instrumentals.htm");
		System.out.println("9 for your own path");
		System.out.println();
		
	}
	public static void printSortMenuOwnPath(){
		System.out.println("Please enter an absolute path. example c:\\my_music");
		System.out.println();	
	}
}
