/***************************************************************

** Michael DePouw

** COP3503

** Assignment Number: 

** Date:

***************************************************************/
import java.io.*;

public class TitCreator{
	private String direct;
	public TitCreator(){

	}
	public void setDirect(String in){
		direct = in;
	}
	public void create() throws IOException{
		String[] directories;
		String tmpS = new String();//user input
		File fileIn = new File(direct);
		//listing directories
		directories = fileIn.list();
		if(directories !=null){
			for(int i=0;i<directories.length;i++){
				File testIsFile = new File(direct+"\\"+directories[i]);
				if(!testIsFile.isFile()){
					File test = new File(direct+"\\"+directories[i]+"\\"+directories[i]+".tit");
					//making sure the tit file doesn't all ready exist
					if(!test.exists()){
						System.out.println("Directory: "+directories[i]);
						BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
						tmpS = in.readLine();
						String tmpS2 = new String();//user input missing '
						//getting rid of ' and replacing with &rsquo;
						for(int j=0;j<tmpS.length();j++){
							if(tmpS.charAt(j) == '\''){
								tmpS2 += "&rsquo;";
							}
							else{
								tmpS2 += tmpS.charAt(j);
							}
						}
						//printing title to a file
						PrintWriter pWriter = new PrintWriter(new FileOutputStream(direct+"\\"+directories[i]+"\\"+directories[i]+".tit"), true);
						pWriter.println(tmpS2);
						pWriter.close();
					}
				}
			}//end for loop
		}
	}
}