/***************************************************************

** Michael DePouw

** COP3530

** Assignment Number: 3

** Date:4-11-03

***************************************************************/

/****************Class Description***************************

** 

**************************************************************/
    public class Vertex{
   
      String city;
      int numIncidentEdges;
      int index;
   
       public Vertex(String cityIn, int NumIn, int indexIn){
      
         city = cityIn;
         numIncidentEdges = NumIn;
         index = indexIn;
      }	
   }