CREATE PROCEDURE TestUnion2 AS

CREATE TABLE #temptable (fname VARCHAR(50), lname VARCHAR(50))

INSERT INTO #temptable
SELECT fname, lname  FROM employee
UNION
SELECT au_fname, au_lname FROM authors

SELECT * FROM #temptable

DROP TABLE #temptable