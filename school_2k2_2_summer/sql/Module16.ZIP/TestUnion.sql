CREATE PROCEDURE TestUnion AS

SELECT fname, lname INTO #temptable FROM employee
UNION
SELECT au_fname, au_lname FROM authors

SELECT * FROM #temptable

DROP TABLE #temptable

