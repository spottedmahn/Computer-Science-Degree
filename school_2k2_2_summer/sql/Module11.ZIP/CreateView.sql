CREATE VIEW dbo.vwStudentPortfolioContents
AS
SELECT dbo.Student.Student_ID, dbo.Student.First_Name,
��� dbo.Student.Last_Name, dbo.Subject_Matter.Subject_Matter_Name,
��� dbo.Portfolio_Contents.Content_Path, dbo.Student.Active AS
��� ActiveStucent, dbo.Portfolio.Active AS ActivePortfolio 
FROM dbo.Student INNER JOIN dbo.Portfolio ON dbo.Student.Student_ID =
��� dbo.Portfolio.Student_ID INNER JOIN dbo.Portfolio_Contents ON
��� dbo.Portfolio.Portfolio_ID = dbo.Portfolio_Contents.Portfolio_ID INNER
��� JOIN dbo.Subject_Matter ON dbo.Portfolio.Subject_Matter_ID =
��� dbo.Subject_Matter.Subject_Matter_ID 
WHERE (dbo.Student.Active = 1) AND (dbo.Portfolio.Active = 1) 