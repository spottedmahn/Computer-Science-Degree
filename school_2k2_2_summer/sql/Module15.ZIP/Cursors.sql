CREATE PROCEDURE Cursors

@AuthorLastName VARCHAR(40),
@PassedCursor CURSOR VARYING OUTPUT

AS

DECLARE @au_id varchar(11), @au_fname varchar(20), @au_lname varchar(40)
DECLARE curAuthor CURSOR FOR SELECT au_id, au_fname, au_lname FROM authors
OPEN curAuthor

FETCH NEXT FROM curAuthor INTO @au_id, @au_fname, @au_lname
FETCH NEXT FROM @PassedCursor

WHILE @@FETCH_STATUS = 0
BEGIN
    IF @au_lname = @AuthorLastName
    BEGIN
        FETCH RELATIVE 0 FROM @PassedCursor
        RETURN 99  
    END       
    FETCH NEXT FROM curAuthor INTO @au_id, @au_fname, @au_lname
    FETCH NEXT FROM @PassedCursor
END
